# PRODIGY_DS_04-Intern-Pinaki-Jupyter-Lab-TASK-04
As an Intern, I have created and completed in 12-14 days in Jupyter Lab as per the task of Prodigy InfoTech i.e., DATA SCIENCE ----TASK 4.

Task : Analyze and visualize sentiment patterns in social media data to understand public opinion and attitudes towards specific topics or brands.



https://github.com/PINAKIMATHAN/PRODIGY_DS_04-Intern-Pinaki-Jupyter-Lab-TASK-04/assets/107812574/057d7ac3-92a5-4d53-891b-0682ce73a364

